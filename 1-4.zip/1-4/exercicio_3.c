#include <stdio.h>

int busca_binaria(int vetor[], int a, int e, int d)
{
	if(d >= e){
		int n = (e + d)/2;
		if(vetor[n] == a){ 
		}
		if(vetor[n] < a){
			printf("%d descartados: \n", d-n);
			return busca_binaria(vetor, a, n+1, d); 
		}
		if(vetor[n] > a){
				printf("%d descartados: \n", d-n);
			return busca_binaria(vetor, a, e, n-1); 
		}
	}
}

main(){
	
	int size, f, i;
	
	printf("Qual o tamanho do vetor? \n");
	scanf("%d", &size);
	printf("digite os numeros do vetor: \n\n");
	int vetor[size];
	for(i=0; i<size; i++){
		printf("numero %d: ", i+1);
		scanf("%d", &vetor[i]);
	}
	system("cls");
	printf("informe o que busca: ");
	scanf("%d", &f);
	
	int a = busca_binaria(vetor, f, 0, size-1);
	if(a == -1){
		system("cls");
		printf("%d \n", a);
		printf("\n o numero nao esta no vetor \n\n");
	}
}
