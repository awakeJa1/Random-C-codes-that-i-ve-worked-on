#include <stdio.h>

int busca_sequencial(int vetor[], int n, int e, int d)
{
	if(d >= e){
		int input = (e + d)/2;
		if(vetor[input] == n){
			return input;
		}
		if(vetor[input] < n){
			return busca_sequencial(vetor, n, input+1, d);
		}
		if(vetor[input] > n){
			return busca_sequencial(vetor, n, e, input-1);
		}
	}
}

void ordenador(int vetor[]){
    int i, k, t;
    for( i=0; i<4; i++ ){
        for( k=i+1; k<4; k++ ){
            if( vetor[i] > vetor[k] ){
                t   = vetor[i];
                vetor[i] = vetor[k];
                vetor[k] = t;
            }
        }
    }
}

main(void){

	int tamanho, b, i;
	printf("Qual o tamanho do vetor? \n");
	scanf("%d", &tamanho);
	int vetor[tamanho];
	for(i=0; i<tamanho; i++){
		printf("numero %d: ", i+1);
		scanf("%d", &vetor[i]);
	}
	
	ordenador(vetor);
	printf("Qual numero deseja procurar? ");
	scanf("%d", &b);
	
	int c = busca_sequencial(vetor, b, 0, tamanho-1);
	if(c == -1){
		printf("%d \n", c);
		printf("\n nao foi encontrado \n \n");
	}
	else{
		system("cls");
		printf("\n\n");
		printf("o numero %d esta no ponto %d do vetor \n \n", b, c+1);
	}
}
